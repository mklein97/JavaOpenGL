in vec2 v_texCoord;
out vec4 color;
uniform sampler2DArray textures;

void main() {
	color = vec4(0);
	for (int i = 1; i < blurRadius; i++) {
		float w = blurWeights [i];
		vec4 t = texture(textures, vec3(v_texCoord - (i) * blurDeltas, blurReadLayer));
		color += w * t * blurColorScale;
	}
	for (int i = 0; i < blurRadius; i++) {
		float w = blurWeights [i];
		vec4 t = texture(textures, vec3(v_texCoord + (i) * blurDeltas, blurReadLayer));
		color += w * t * blurColorScale;
	}
	color.a = 1.0;
}