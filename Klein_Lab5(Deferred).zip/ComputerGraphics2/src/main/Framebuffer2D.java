package main;

import static etgg.GL.GL_CLAMP_TO_EDGE;
import static etgg.GL.GL_COLOR_ATTACHMENT0;
import static etgg.GL.GL_COLOR_BUFFER_BIT;
import static etgg.GL.GL_DEPTH24_STENCIL8;
import static etgg.GL.GL_DEPTH_BUFFER_BIT;
import static etgg.GL.GL_DEPTH_STENCIL;
import static etgg.GL.GL_DEPTH_STENCIL_ATTACHMENT;
import static etgg.GL.GL_FRAMEBUFFER;
import static etgg.GL.GL_FRAMEBUFFER_BINDING;
import static etgg.GL.GL_FRAMEBUFFER_COMPLETE;
import static etgg.GL.GL_LINEAR;
import static etgg.GL.GL_NEAREST;
import static etgg.GL.GL_RGBA;
import static etgg.GL.GL_RGBA8;
import static etgg.GL.GL_TEXTURE_2D_ARRAY;
import static etgg.GL.GL_TEXTURE_BINDING_2D_ARRAY;
import static etgg.GL.GL_TEXTURE_MAG_FILTER;
import static etgg.GL.GL_TEXTURE_MIN_FILTER;
import static etgg.GL.GL_TEXTURE_WRAP_S;
import static etgg.GL.GL_TEXTURE_WRAP_T;
import static etgg.GL.GL_UNSIGNED_BYTE;
import static etgg.GL.GL_UNSIGNED_INT_24_8;
import static etgg.GL.GL_VIEWPORT;
import static etgg.GL.glBindFramebuffer;
import static etgg.GL.glBindTexture;
import static etgg.GL.glCheckFramebufferStatus;
import static etgg.GL.glClear;
import static etgg.GL.glDrawBuffers;
import static etgg.GL.glFramebufferTextureLayer;
import static etgg.GL.glGenFramebuffers;
import static etgg.GL.glGenTextures;
import static etgg.GL.glGetIntegerv;
import static etgg.GL.glGetTexImage;
import static etgg.GL.glTexImage3D;
import static etgg.GL.glTexParameteri;
import static etgg.GL.glViewport;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.TreeMap;
import javax.imageio.ImageIO;
import math3d.vec2;


public class Framebuffer2D{
    //tells which RT is currently active, or null if none
    static Framebuffer2D active_target;

    //saved viewport (the one that was active before we switched
    //to this RT
    static int[] saved_viewport = new int[4];

    int[] drawbuffers;
    
    //texture which belongs to this fbo
    Texture2DArray texture;
    
    //z buffer + stencil
    Texture2DArray depthtexture;

    //GL identifier
    int fbo;
    
     //for blurring
    TreeMap<Integer,TreeMap<Integer,Framebuffer2D> > blurHelpers = new TreeMap<>();
    TreeMap<Integer,float[]> blurWeights = new TreeMap<>();
    static final int MAX_BLUR_RADIUS = 30;
    static Program blurProgram;
    static UnitSquare blurUsq;
    
    //Determine if it's ok to bind this fbo for writing
    public void checkOkToBind(){
        if( active_target != null){
            throw new RuntimeException("Another FBO is already bound");
        }
        if(!texture.on_units.isEmpty() ){
            throw new RuntimeException("This FBO has textures that are active");
        }
    }
      
    void unbind(){
        if( active_target != this )
            throw new RuntimeException("This FBO is not bound");
        active_target=null;
        glBindFramebuffer(GL_FRAMEBUFFER,0);
        glViewport(
            saved_viewport[0],saved_viewport[1],
            saved_viewport[2],saved_viewport[3]);
    }
    
    public Framebuffer2D(int width, int height,  int format, int slices){
        texture = new Texture2DArray();
        int[] tmp = new int[1];
        glGenTextures(1,tmp);
        texture.tex = tmp[0];
        texture.bind(0);
        texture.w = width;
        texture.h = height;
        texture.slices = slices;
        texture.owning_fbo = this;
        glTexImage3D(GL_TEXTURE_2D_ARRAY, 0, format, width,height,texture.slices, 0, 
                GL_RGBA, GL_UNSIGNED_BYTE, (byte[])null );
        glTexParameteri(GL_TEXTURE_2D_ARRAY , GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D_ARRAY , GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D_ARRAY , GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D_ARRAY , GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        texture.unbind(0);
        
        depthtexture = new Texture2DArray();
        depthtexture.owning_fbo = this;
        glGenTextures(1,tmp);
        depthtexture.tex = tmp[0];
        depthtexture.bind(0);
        depthtexture.w = width;
        depthtexture.h = height;
        depthtexture.slices = 1;
        glTexImage3D(GL_TEXTURE_2D_ARRAY , 0, GL_DEPTH24_STENCIL8, width,height,depthtexture.slices,0, 
            GL_DEPTH_STENCIL, GL_UNSIGNED_INT_24_8, (byte[])null );
        glTexParameteri(GL_TEXTURE_2D_ARRAY , GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D_ARRAY , GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D_ARRAY , GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D_ARRAY , GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        depthtexture.unbind(0);
        
        glGenFramebuffers(1,tmp);
        fbo = tmp[0];
        glBindFramebuffer(GL_FRAMEBUFFER, fbo );
        
        for(int i=0;i<slices;++i){
            //target, attachment, texture, mip level, layer
            glFramebufferTextureLayer(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0+i, texture.tex, 0, i);
        }
        glFramebufferTextureLayer(GL_FRAMEBUFFER,GL_DEPTH_STENCIL_ATTACHMENT, depthtexture.tex, 0, 0 );
            
        int complete = glCheckFramebufferStatus(GL_FRAMEBUFFER);
        if( complete != GL_FRAMEBUFFER_COMPLETE ){
            throw new RuntimeException("Framebuffer is not complete: "+complete);
        }
        
        drawbuffers = new int[slices];
        for(int i=0;i<slices;++i)
            drawbuffers[i] = GL_COLOR_ATTACHMENT0+i;
        
        glBindFramebuffer(GL_FRAMEBUFFER,0);
        
    }
    
    void bind(boolean clearIt){
        if( active_target != null ){
            active_target.unbind();
        }
        checkOkToBind();
        active_target = this;
        glBindFramebuffer(GL_FRAMEBUFFER,fbo);

        glDrawBuffers(drawbuffers.length,drawbuffers);
        
        glGetIntegerv(GL_VIEWPORT,saved_viewport);
        glViewport(0,0,texture.w,texture.h);
        
        if( clearIt )
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
      
    }
    
    
    /** Blur this FBO.
    @param radius The blur radius
    @param inputLayer Which layer (slice) to read from
    @param colorScale How much to scale the colors. Useful for emission maps.
    Note: The output of the blur is always to slot 0!
    */
    void blur(int radius, int inputLayer, float colorScale){
        if( radius <= 0 )
            return;
        
        if( !blurWeights.containsKey(radius) ){
            float[] F = new float[MAX_BLUR_RADIUS];
            float sigma = radius/3.0f;
            float sum = 0.0f;
            for(int i=0;i<=radius;++i){
                //box blur
                //float tmp = 1.0f/(radius+radius+1);
                //F[i] = tmp;
                //Gaussian blur
                float Q = i*i / (-2 * sigma*sigma );
                F[i] = (float)(Math.exp(Q) / (sigma * Math.sqrt(2*Math.PI)));
                if(i == 0 )
                    sum += F[i];
                else
                    sum += 2.0*F[i];
            }
            for(int i=0;i<=radius;++i)
                F[i] /= sum;
            blurWeights.put(radius,F);
        }
        if( !blurHelpers.containsKey(this.texture.w))
            blurHelpers.put(this.texture.w,new TreeMap<>());
        if( !blurHelpers.get(this.texture.w).containsKey(this.texture.h) )
            blurHelpers.get(this.texture.w).put(this.texture.h,new Framebuffer2D(this.texture.w,this.texture.h, GL_RGBA8, 1 ));
        if( blurProgram == null ){
            blurProgram = new Program("blur.vs",null,"blur.fs");
            blurUsq = new UnitSquare();
        }
        
        Framebuffer2D helper = blurHelpers.get(this.texture.w).get(this.texture.h);
        
        Program oldProg = Program.current;
        Framebuffer2D oldfbo = Framebuffer2D.active_target;
        
        blurProgram.use();
        blurProgram.setUniform("blurWeights", blurWeights.get(radius));
        blurProgram.setUniform("blurRadius", radius);
        
        helper.bind(true);
        blurProgram.setUniform("blurReadLayer", inputLayer);
        blurProgram.setUniform("textures",this.texture);
        blurProgram.setUniform("blurDeltas", new vec2(1.0/this.texture.w, 0));
        blurProgram.setUniform("blurColorScale", colorScale);
        blurUsq.draw();
        helper.unbind();
        
        this.texture.unbind();
        this.bind(true);
        blurProgram.setUniform("blurReadLayer", inputLayer);
        blurProgram.setUniform("textures", helper.texture);
        blurProgram.setUniform("blurDeltas", new vec2(0, 1.0/this.texture.h));
        blurProgram.setUniform("blurColorScale", colorScale);
        blurUsq.draw();
        this.unbind();
        helper.texture.unbind();
        
        oldProg.use();
        if( oldfbo != null )
            oldfbo.bind(false);
    }
    
    /**Debugging. Dump the contents of this FBO's layers to a series
        of PNG files.*/
    void dump(String filename){
        int[] tmp = new int[1];
        glGetIntegerv(GL_FRAMEBUFFER_BINDING, tmp);
        //System.out.println("DEBUG: Current framebuffer is "+tmp[0]);
        glBindFramebuffer(GL_FRAMEBUFFER,0);
        byte[] B = new byte[texture.w*texture.h*4*texture.slices];
        int[] tmp2 = new int[1];
        glGetIntegerv(GL_TEXTURE_BINDING_2D_ARRAY, tmp2);
        glBindTexture(GL_TEXTURE_2D_ARRAY, this.texture.tex);
        glGetTexImage(GL_TEXTURE_2D_ARRAY, 0, GL_RGBA, GL_UNSIGNED_BYTE, B);
        glBindTexture(GL_TEXTURE_2D_ARRAY,tmp2[0]);
        glBindFramebuffer(GL_FRAMEBUFFER,tmp[0]);
        
        int[] rgb = new int[texture.w*texture.h];
        int k=0;
        for(int i=0;i<texture.slices;++i){
            BufferedImage img = new BufferedImage(texture.w,texture.h,BufferedImage.TYPE_INT_ARGB);
            for(int y=0;y<texture.h;++y){
                int m = (texture.h-1-y)*texture.w;
                for(int x=0;x<texture.w;++x){
                    int r = B[k++];
                    r &= 0xff;
                    int g = B[k++];
                    g &= 0xff;
                    int b = B[k++];
                    b &= 0xff;
                    int a = B[k++];
                    a &= 0xff;
                    rgb[m++] = (a<<24) | (r<<16) | (g<<8) | b;
                }
            }
            img.setRGB(0,0,img.getWidth(),img.getHeight(),rgb,0,img.getWidth());
            try{
                String fn = filename+"-layer"+i+".png";
                ImageIO.write(img, "png", new File(fn) );
                System.out.println("Wrote "+fn);
            }catch(IOException e){
                throw new RuntimeException(e);
            }
        }
        
    }
       
};
