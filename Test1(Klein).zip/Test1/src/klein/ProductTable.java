package klein;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Matt
 */
public class ProductTable {
    public ArrayList row;
    public ArrayList col;
    Random r = new Random();
    
    public ProductTable(float min, float max){
        float random = min + r.nextFloat() * (max - min);
        this.row = new ArrayList<Float>();
        this.col = new ArrayList<Float>();
        row.add(random);
        col.add(random);
        float rMin = min;
        float rMax = max;
    }
 
    if (row.length()){
      
    }  
    
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
