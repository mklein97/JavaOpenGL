package etgg;

public class Debug{
    public static void showCurrentFramebuffer(){}
    public static void showCurrentTexture(){}
    
}
