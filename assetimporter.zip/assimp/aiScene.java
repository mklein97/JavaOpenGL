package assimp;
//Based on assimp, which has these copyrights:
/*
Open Asset Import Library (assimp)
----------------------------------------------------------------------

Copyright (c) 2006-2012, assimp team
All rights reserved.

Redistribution and use of this software in source and binary forms, 
with or without modification, are permitted provided that the 
following conditions are met:

* Redistributions of source code must retain the above
  copyright notice, this list of conditions and the
  following disclaimer.

* Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the
  following disclaimer in the documentation and/or other
  materials provided with the distribution.

* Neither the name of the assimp team, nor the names of its
  contributors may be used to endorse or promote products
  derived from this software without specific prior
  written permission of the assimp team.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

----------------------------------------------------------------------
---------------------------------------------------------------------------
Open Asset Import Library (assimp)
---------------------------------------------------------------------------

Copyright (c) 2006-2012, assimp team

All rights reserved.

Redistribution and use of this software in source and binary forms, 
with or without modification, are permitted provided that the following 
conditions are met:

* Redistributions of source code must retain the above
  copyright notice, this list of conditions and the
  following disclaimer.

* Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the
  following disclaimer in the documentation and/or other
  materials provided with the distribution.

* Neither the name of the assimp team, nor the names of its
  contributors may be used to endorse or promote products
  derived from this software without specific prior
  written permission of the assimp team.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
---------------------------------------------------------------------------
---------------------------------------------------------------------------
Open Asset Import Library (assimp)
---------------------------------------------------------------------------

Copyright (c) 2006-2011, assimp team

All rights reserved.

Redistribution and use of this software in source and binary forms, 
with or without modification, are permitted provided that the following 
conditions are met:

* Redistributions of source code must retain the above
copyright notice, this list of conditions and the
following disclaimer.

* Redistributions in binary form must reproduce the above
copyright notice, this list of conditions and the
following disclaimer in the documentation and/or other
materials provided with the distribution.

* Neither the name of the assimp team, nor the names of its
contributors may be used to endorse or promote products
derived from this software without specific prior
written permission of the assimp team.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
---------------------------------------------------------------------------*/
import com.sun.jna.*;
import java.util.*;
public class aiScene extends Structure {
    public static class ByValue extends aiScene implements Structure.ByValue{}
    public static class ByReference extends aiScene implements Structure.ByReference{}
    public int mFlags;  //int mFlags
    public aiNode.ByReference mRootNode;  //C_STRUCT aiNode* mRootNode
    public int mNumMeshes;  //int mNumMeshes
    public Pointer mMeshes;  //C_STRUCT aiMesh** mMeshes
    public int mNumMaterials;  //int mNumMaterials
    public Pointer mMaterials;  //C_STRUCT aiMaterial** mMaterials
    public int mNumAnimations;  //int mNumAnimations
    public Pointer mAnimations;  //C_STRUCT aiAnimation** mAnimations
    public int mNumTextures;  //int mNumTextures
    public Pointer mTextures;  //C_STRUCT aiTexture** mTextures
    public int mNumLights;  //int mNumLights
    public Pointer mLights;  //C_STRUCT aiLight** mLights
    public int mNumCameras;  //int mNumCameras
    public Pointer mCameras;  //C_STRUCT aiCamera** mCameras
    public Pointer mPrivate;  //char* mPrivate
    public List<String> getFieldOrder(){
        return Arrays.asList(new String[]{"mFlags","mRootNode","mNumMeshes","mMeshes","mNumMaterials","mMaterials","mNumAnimations","mAnimations","mNumTextures","mTextures","mNumLights","mLights","mNumCameras","mCameras","mPrivate"});
    }

    public aiMesh[] getMeshes(){
        Pointer[] A = this.mMeshes.getPointerArray(0,this.mNumMeshes);
        aiMesh[] ret = new aiMesh[A.length];
        for(int i=0;i<A.length;++i){
            ret[i] = (aiMesh) Structure.newInstance(aiMesh.class,A[i]);
            ret[i].read();
        }
        return ret;
    }
    public aiMaterial[] getMaterials(){
        Pointer[] A = this.mMaterials.getPointerArray(0,this.mNumMaterials);
        aiMaterial[] ret = new aiMaterial[A.length];
        for(int i=0;i<A.length;++i){
            ret[i] = (aiMaterial) Structure.newInstance(aiMaterial.class,A[i]);
            ret[i].read();
        }
        return ret;
    }
    
    public aiAnimation[] getAnimations(){
        Pointer[] AA = this.mAnimations.getPointerArray(0,this.mNumAnimations);
        aiAnimation[] ret = new aiAnimation[AA.length];
        for(int i=0;i<ret.length;++i){
            ret[i] = (aiAnimation) Structure.newInstance(aiAnimation.class, AA[i]);
            ret[i].read();
        }
        return ret;
    }



}
