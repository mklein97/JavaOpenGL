package etec2101;

/**
 *
 * @author Matt
 */
public class Map {
    
}
