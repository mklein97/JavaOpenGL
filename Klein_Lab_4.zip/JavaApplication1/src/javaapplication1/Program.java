package javaapplication1;

import static etgg.GL.GL_COMPILE_STATUS;
import static etgg.GL.GL_FRAGMENT_SHADER;
import static etgg.GL.GL_LINK_STATUS;
import static etgg.GL.GL_VERTEX_SHADER;
import static etgg.GL.glAttachShader;
import static etgg.GL.glBindAttribLocation;
import static etgg.GL.glCompileShader;
import static etgg.GL.glCreateProgram;
import static etgg.GL.glCreateShader;
import static etgg.GL.glGetProgramInfoLog;
import static etgg.GL.glGetProgramiv;
import static etgg.GL.glGetShaderInfoLog;
import static etgg.GL.glGetShaderiv;
import static etgg.GL.glLinkProgram;
import static etgg.GL.glShaderSource;
import static etgg.GL.glUseProgram;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Program {
    int prog;
    String identifier;
    static Program current;
    static final int POSITION_INDEX = 0;
    public Program(String vsfname, String fsfname){
        identifier = vsfname+"+"+fsfname;
        int vs = compile(vsfname, GL_VERTEX_SHADER);
        int fs = compile(fsfname, GL_FRAGMENT_SHADER);
        prog = glCreateProgram();
        glAttachShader(prog,vs);
        glAttachShader(prog,fs);
        bindAttributeLocations();
        link();
    }
    
    void use(){
        glUseProgram(prog);
        current = this;
    }
    
    void link(){
        glLinkProgram(prog);
        
        byte[] infolog = new byte[4000];
        int[] length = new int[1];
        glGetProgramInfoLog(prog,infolog.length, length, infolog);
        if( length[0] > 0 ){
            String tmp2 = new String(infolog,0,length[0]);
            System.out.println("When linking "+identifier+":");
            System.out.println(tmp2);
        }
        
        int[] status = new int[1];
        glGetProgramiv(prog,GL_LINK_STATUS,status);
        if( status[0] == 0 ){
            System.out.println("Link of program "+identifier+" failed");
            System.exit(1);
        }
    }
    
    void bindAttributeLocations(){
        glBindAttribLocation(prog,POSITION_INDEX, "position");
    }
    
    int compile(String fname, int type){
        int s = glCreateShader(type);
        String sdata;
        try {
            sdata = new String(Files.readAllBytes(FileSystems.getDefault().getPath(fname)));
        } catch (IOException ex) {
            System.out.println("Can't load shader "+fname);
            System.exit(0);
            return -1;      //never executes!
        }
        
        String[] tmp = new String[1];
        tmp[0]=sdata;
        int[] length = new int[1];
        length[0] = sdata.length();
        glShaderSource(s,1,tmp,length);
        glCompileShader(s);
        
        byte[] infolog = new byte[4000];
        glGetShaderInfoLog(s,infolog.length, length, infolog);
        if( length[0] > 0 ){
            System.out.println("When compiling "+fname+":");
            String tmp2 = new String(infolog,0,length[0]);
            System.out.println(tmp2);
        }
        
        int[] status = new int[1];
        glGetShaderiv(s,GL_COMPILE_STATUS,status);
        if( status[0] == 0 ){
            System.out.println("Compile of shader "+fname+" failed");
            System.exit(1);
            return -1;
        }
        return s;
    }
}