package javaapplication1;

import static etgg.SDL.*;
import static etgg.GL.*;

/**
 *
 * @author jhudson
 */
public class Simple {

    public static void main(String[] args) {
        SDL_Init(SDL_INIT_VIDEO);
        SDL_Window win = SDL_CreateWindow("ETGG", 20, 20, 512, 512, SDL_WINDOW_OPENGL);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
        SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
        SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 8);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_FLAGS, SDL_GL_CONTEXT_DEBUG_FLAG);
        SDL_GL_CreateContext(win);

        glDebugMessageCallback(
                (int source, int type, int id, int severity, int length, String message, Object param)
                -> {
                    System.out.println(message);
                },
                null
        );

        glDebugMessageControl(GL_DONT_CARE,GL_DONT_CARE, GL_DONT_CARE, 0, null, true );
        glEnable(GL_DEBUG_OUTPUT_SYNCHRONOUS);
        glEnable(GL_DEBUG_OUTPUT);
        
        Pyramid foo = new Pyramid();
        Program prog = new Program("prog1.vs", "prog1.fs");
        prog.use();

        glClearColor(0.2f, 0.4f, 0.6f, 1.0f);
        SDL_Event ev = new SDL_Event();
        float red = 0.0f, green = 0.0f, blue = 0.0f;

        while (true) {
            while (true) {
                if (0 == SDL_PollEvent(ev)) {
                    break;
                }
                if (ev.type == SDL_QUIT) {
                    System.exit(0);
                } else if (ev.type == SDL_KEYDOWN) {
                    //SDL_KeyboardEvent k = (SDL_KeyboardEvent) ev.readField("key");
                    //use k.keysym.sym
                } else if (ev.type == SDL_KEYUP) {
                    //SDL_KeyboardEvent k = (SDL_KeyboardEvent) ev.readField("key");
                    //use k.keysym.sym
                } else if (ev.type == SDL_MOUSEMOTION) {
                    //SDL_MouseMotionEvent m = (SDL_MouseMotionEvent)ev.readField("motion");
                    //use m.x and m.y
                } else if (ev.type == SDL_MOUSEBUTTONDOWN) {
                    SDL_MouseButtonEvent b = (SDL_MouseButtonEvent) ev.readField("button");
                    if (b.button == 1) {
                        red = 1.0f - red;
                    }
                    if (b.button == 2) {
                        green = 1.0f - green;
                    }
                    if (b.button == 3) {
                        blue = 1.0f - blue;
                    }
                }
            }
            glClearColor(red, green, blue, 1.0f);
            glClear(GL_COLOR_BUFFER_BIT);

            foo.draw();

            SDL_GL_SwapWindow(win);
        }
    }
}