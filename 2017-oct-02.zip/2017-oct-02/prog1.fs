#version 150
out vec4 color;
void main(){
    if(int(gl_FragCoord.x)  % 2 == 0 ){
        color = vec4(1,0,0,1);
    }
    else{
        color = vec4(1,1,1,1);
    }
}
