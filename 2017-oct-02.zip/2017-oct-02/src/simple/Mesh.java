/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simple;

import static etgg.GL.GL_ARRAY_BUFFER;
import static etgg.GL.GL_ELEMENT_ARRAY_BUFFER;
import static etgg.GL.GL_FLOAT;
import static etgg.GL.GL_STATIC_DRAW;
import static etgg.GL.GL_TRIANGLES;
import static etgg.GL.GL_UNSIGNED_INT;
import static etgg.GL.glBindBuffer;
import static etgg.GL.glBindVertexArray;
import static etgg.GL.glBufferData;
import static etgg.GL.glDrawElements;
import static etgg.GL.glEnableVertexAttribArray;
import static etgg.GL.glGenBuffers;
import static etgg.GL.glGenVertexArrays;
import static etgg.GL.glVertexAttribPointer;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.Path;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jhudson
 */
public class Mesh {
    int vao;
    int numi;
    Mesh(String filename){
        //delegate operations to common function
        init(filename);
    }
    Mesh(Path filename){
        init(filename.toString());
    }
    void init(String path){
        try {
            RandomAccessFile raf = new RandomAccessFile(path,"r");
            
            int[] tmp = new int[1];
            glGenVertexArrays(1, tmp);
            this.vao = tmp[0];
            glBindVertexArray(vao);
        
            String s;
            s = raf.readUTF();
            if( !"mesh0".equals(s)){ //  !s.equals("mesh0"))
                throw new RuntimeException("Bad mesh format");
            }
            s = raf.readUTF();
            if(!"numv".equals(s))
                throw new RuntimeException("Bad");
            int numv = raf.readInt();
            s = raf.readUTF();
            if(!"numi".equals(s))
                throw new RuntimeException("Bad");
            numi = raf.readInt();
            s = raf.readUTF();
            if(!"positions".equals(s))
                throw new RuntimeException("Bad");
                    
            //4 bytes per float, numv vertices, 3 floats per vertex (x,y,z)
            byte[] vdata = new byte[  4 * numv * 3 ];
            //vdata gets filled with informatin from the file
            raf.readFully(vdata);
            
            glGenBuffers(1,tmp);
            int vbuff = tmp[0];
            glBindBuffer(GL_ARRAY_BUFFER,vbuff);
            glBufferData(GL_ARRAY_BUFFER,vdata.length,vdata,GL_STATIC_DRAW);
            glVertexAttribPointer(Program.POSITION_INDEX, 3, GL_FLOAT,
                    false, 3*4, 0);
            glEnableVertexAttribArray(Program.POSITION_INDEX);

            s = raf.readUTF();
            if( !s.equals("indices"))
                throw new RuntimeException("Bad");
            
            //4 bytes per index
            byte[] idata = new byte[numi * 4];
            raf.readFully(idata);
            glGenBuffers(1,tmp);
            int ibuff = tmp[0];
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,ibuff);
            glBufferData(GL_ELEMENT_ARRAY_BUFFER,idata.length,idata,GL_STATIC_DRAW);
        
            s = raf.readUTF();
            if( !s.equals("end"))
                throw new RuntimeException("Extra junk at end of file");
            
            glBindVertexArray(0);
            raf.close();
        } catch (FileNotFoundException ex) {
            throw new RuntimeException("Cannot load mesh "+path);
        } catch (IOException ex) {
            throw new RuntimeException("IO exception: "+path);
        }
        
    }
    void draw(){
        glBindVertexArray(this.vao);
        glDrawElements(GL_TRIANGLES, numi, GL_UNSIGNED_INT, 0);    }
}
