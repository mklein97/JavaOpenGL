
package simple;

/**
 *
 * @author jhudson
 */
public class Sphere {
    //put sphere stuff in here
    Sphere(){
    }
    void draw(){
    }
}
