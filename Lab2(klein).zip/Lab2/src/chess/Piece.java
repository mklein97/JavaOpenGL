package chess;

public abstract class Piece {

    protected int myColumn, myRow;
    protected boolean isWhite;
    protected boolean hasMoved = false;

    public Piece(int r, int c, boolean white) {
        isWhite = white;
        myRow = r;
        myColumn = c;
    }

    public int get_column() {
        return myColumn;
    }

    public int get_row() {
        return myRow;
    }

    public boolean get_is_white() {
        return isWhite;
    }

    public boolean get_occupied(Piece[] all_pieces, int row, int col) {
        if (row < 0 || row >= 8 || col < 0 || col >= 8) {
            return true;
        }
        for (Piece p : all_pieces) {
            if (p.get_row() == row && p.get_column() == col) {
                return true;
            }
        }
        return false;
    }

    public boolean make_move(int new_row, int new_col, Piece[] pieces) {
        Point[] points = get_valid_moves(pieces);
        boolean valid_move = false;
        for (Point p : points) {
            if (p.row == new_row && p.col == new_col) {
                valid_move = true;
                break;
            }
        }
        if (valid_move) {
            myRow = new_row;
            myColumn = new_col;
            hasMoved = true;
            return true;
        }
        return false;
    }

    public abstract Point[] get_valid_moves(Piece[] all_pieces);

}
