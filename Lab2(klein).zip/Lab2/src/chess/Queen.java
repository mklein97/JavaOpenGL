package chess;

public class Queen extends Piece {
    public Queen(int r, int c, boolean white) {
        super(r, c, white);
    }
    
    @Override
    public Point[] get_valid_moves(Piece[] all_pieces) {
        Point[] points = new Point[64];
        int n = 0;
        
        //forwards
        for (int i = 1; i < 8; i++){
            if (!get_occupied(all_pieces, myRow + i, myColumn)){
                points[n] = new Point(myRow + i, myColumn);
                n++;
            }
            else {
                break;
            }
        }
        //backwards
        for (int i = 1; i < 8; i++){
            if (!get_occupied(all_pieces, myRow - i, myColumn)){
                points[n] = new Point(myRow - i, myColumn);
                n++;
            }
            else {
                break;
            }
        }
        //leftwards
        for (int i = 1; i < 8; i++){
            if (!get_occupied(all_pieces, myRow, myColumn - i)){
                points[n] = new Point(myRow, myColumn - i);
                n++;
            }
            else {
                break;
            }
        }
        //rightwards
        for (int i = 1; i < 8; i++){
            if (!get_occupied(all_pieces, myRow, myColumn + i)){
                points[n] = new Point(myRow, myColumn + i);
                n++;
            }
            else {
                break;
            }
        }
        //northeast
        for (int i = 1; i < 8; i++){
            if (!get_occupied(all_pieces, myRow + i, myColumn + i)){
                points[n] = new Point(myRow + i, myColumn + i);
                n++;
            }
            else {
                break;
            }
        }
        //northwest
        for (int i = 1; i < 8; i++){
            if (!get_occupied(all_pieces, myRow + i, myColumn - i)){
                points[n] = new Point(myRow + i, myColumn + i);
                n++;
            }
            else {
                break;
            }
        }
        //southeast
        for (int i = 1; i < 8; i++){
            if (!get_occupied(all_pieces, myRow - i, myColumn + i)){
                points[n] = new Point(myRow - i, myColumn + i);
                n++;
            }
            else {
                break;
            }
        }
        //southwest
        for (int i = 1; i < 8; i++){
            if (!get_occupied(all_pieces, myRow - i, myColumn - i)){
                points[n] = new Point(myRow - i, myColumn - i);
                n++;
            }
            else {
                break;
            }
        }

        Point[] point_list = new Point[n];
        System.arraycopy(points, 0, point_list, 0, n);
        return point_list;
    }
}
