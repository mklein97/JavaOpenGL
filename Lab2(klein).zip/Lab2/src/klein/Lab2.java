package klein;

import chess.*;

public class Lab2 {

    public static void main(String[] args) {
        //Pawn Test
        {
            System.out.println("Testing Pawn move forward 2 spaces (empty board):");
            Pawn pawn = new Pawn(4, 4, true);
            Piece[] pieces = new Piece[0];
            if (pawn.make_move(6, 4, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
            //can't move 2 spaces if already moved
            System.out.println("Testing Pawn move forward 2 spaces after already moved (empty board):");
            if (pawn.make_move(8, 4, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
            System.out.println("Testing pawn move forward (space occupied):");
            pieces = new Piece[1];
            pieces[0] = new Pawn(7, 4, false);
            if (pawn.make_move(7, 4, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
        }

        //Rook test
        {
            System.out.println("Testing Rook move forward 4 spaces (empty board):");
            Rook rook = new Rook(1, 4, true);
            Piece[] pieces = new Piece[0];
            if (rook.make_move(5, 4, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
            System.out.println("Testing Rook move backward 2 spaces (empty board):");
            if (rook.make_move(2, 4, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
            System.out.println("Testing Rook move left 2 spaces (empty board):");
            if (rook.make_move(2, 2, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
            System.out.println("Testing Rook move right 2 spaces (empty board):");
            if (rook.make_move(2, 4, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
            System.out.println("Testing Rook move northeast 1 space (empty board):");
            if (rook.make_move(3, 5, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
        }
        
        //Bishop test
        {
            System.out.println("Testing Bishop move northeast 2 spaces (empty board):");
            Bishop bishop = new Bishop(4, 4, true);
            Piece[] pieces = new Piece[0];
            if (bishop.make_move(6, 6, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
            System.out.println("Testing Bishop move northwest 1 space (empty board):");
            if (bishop.make_move(7, 5, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
            System.out.println("Testing Bishop move southwest 2 spaces (empty board):");
            if (bishop.make_move(5, 3, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
            System.out.println("Testing Bishop move southeast 1 space (empty board):");
            if (bishop.make_move(4, 4, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
            System.out.println("Testing Bishop move right 1 space (empty board):");
            if (bishop.make_move(4, 5, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
        }
        
        //Knight test
        {
            System.out.println("Testing Knight move left 2 spaces and up 1 (empty board):");
            Knight knight = new Knight(4, 4, true);
            Piece[] pieces = new Piece[0];
            if (knight.make_move(2, 5, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
            System.out.println("Testing Knight move right 1 space and up 1 (empty board):");
            if (knight.make_move(3, 6, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
        }
        
        //King test
        {
        System.out.println("Testing King move up 1 space (empty board):");
            King king = new King(4, 4, true);
            Piece[] pieces = new Piece[0];
            if (king.make_move(5, 4, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
            System.out.println("Testing King move up 2 spaces (empty board):");
            if (king.make_move(7, 4, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
        }
        
        //Queen test
        {
            System.out.println("Testing Queen move up 1 space (empty board):");
            Queen queen = new Queen(4, 4, true);
            Piece[] pieces = new Piece[0];
            if (queen.make_move(5, 4, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
            System.out.println("Testing Queen move southeast 3 spaces (empty board):");
            if (queen.make_move(2, 7, pieces)) {
                System.out.println("Moved");
            } else {
                System.out.println("Didn't move");
            }
        }
    }

}