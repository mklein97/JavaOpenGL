#version 150
out vec4 color;
void main(){
    
        color = vec4(0.956, 0.513, 0.062, 1);
    
}