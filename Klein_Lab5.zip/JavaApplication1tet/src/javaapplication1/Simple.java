package javaapplication1;

import com.sun.jna.Pointer;
import static etgg.SDL.*;
import static etgg.GL.*;
import java.util.TreeSet;
import static math3d.functions.translation;
import math3d.vec3;

/**
 *
 * @author jhudson
 */
public class Simple {

    static SDL_Window win;
    static TreeSet<Integer> keysdown = new TreeSet<>();
    static TreeSet<Integer> keysup = new TreeSet<>();
    static float tx, ty, bty;
    static Pyramid foo;
    static Bullet bul;
    static Program prog, prog2;

    static void initGL() {
        SDL_Init(SDL_INIT_VIDEO);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
        SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
        SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 8);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_FLAGS, SDL_GL_CONTEXT_DEBUG_FLAG);
        win = SDL_CreateWindow("ETGG", 20, 20, 512, 512, SDL_WINDOW_OPENGL);
        SDL_GL_CreateContext(win);

        glDebugMessageCallback(
                (int source, int type, int id, int severity, int length, String message, Object param)
                -> {
            System.out.println(message);
        },
                null
        );

        glDebugMessageControl(GL_DONT_CARE, GL_DONT_CARE, GL_DONT_CARE, 0, null, true);
        glEnable(GL_DEBUG_OUTPUT_SYNCHRONOUS);
        glEnable(GL_DEBUG_OUTPUT);
    }

    static void handleEvents() {
        SDL_Event ev = new SDL_Event();
        while (true) {
            if (0 == SDL_PollEvent(ev)) {
                break;
            }
            if (ev.type == SDL_QUIT) {
                System.exit(0);
            } else if (ev.type == SDL_KEYDOWN) {
                SDL_KeyboardEvent k = (SDL_KeyboardEvent) ev.readField("key");
                keysdown.add(k.keysym.sym);
                keysup.remove(k.keysym.sym);
            } else if (ev.type == SDL_KEYUP) {
                SDL_KeyboardEvent k = (SDL_KeyboardEvent) ev.readField("key");
                keysdown.remove(k.keysym.sym);
                keysup.add(k.keysym.sym);
            } else if (ev.type == SDL_MOUSEMOTION) {
                //SDL_MouseMotionEvent m = (SDL_MouseMotionEvent)ev.readField("motion");
                //use m.x and m.y
            } else if (ev.type == SDL_MOUSEBUTTONDOWN) {
                SDL_MouseButtonEvent b = (SDL_MouseButtonEvent) ev.readField("button");
            }
        }
    }

    static void update() {
        if (keysdown.contains(SDLK_d)) {
            tx += 0.0009f;
        }
        if (keysdown.contains(SDLK_a)) {
            tx -= 0.0009f;
        }
        if (keysdown.contains(SDLK_w)) {
            ty += 0.0009f;
        }
        if (keysdown.contains(SDLK_s)) {
            ty -= 0.0009f;
        }
        if (keysdown.contains(SDLK_SPACE)) {
            bty += 0.001f;
        }
        if (keysup.contains(SDLK_SPACE)) {
            bty = ty;
        }
    }

    static void draw() {
        //draw frame
        glClear(GL_COLOR_BUFFER_BIT);

        Program.current.setUniform("foo", 1.2f);

        Program.current.setUniform(
                "worldMatrix",
                translation(tx, ty, 0));
        Program.current.setUniform("objColor", new vec3(1,1,1));

        foo.draw();
        
        Program.current.setUniform("bul", 1.2f);
        
        Program.current.setUniform(
                "worldMatrix",
                translation(tx, bty, 0));
        Program.current.setUniform("objColor", new vec3(0.956, 0.513, 0.062));
        
        bul.draw();

        SDL_GL_SwapWindow(win);
    }
    
    

    public static void main(String[] args) {

        initGL();

        foo = new Pyramid();
        
        prog = new Program("prog1.vs", "prog1.fs");

        glClearColor(0.2f, 0.4f, 0.6f, 1.0f);
        
        bul = new Bullet();
        
        prog.use();
        
        while (true) {
            handleEvents();
            update();
            draw();
        }
    }
}