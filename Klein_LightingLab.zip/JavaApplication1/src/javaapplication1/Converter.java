/*
 */
package javaapplication1; 

import assimp.*;
import static assimp.AI.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

public class Converter {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        System.out.println(aiGetVersionMajor()+"."+aiGetVersionMinor()+"."+aiGetVersionRevision());
        JFileChooser jf = new JFileChooser("assets");
        jf.setMultiSelectionEnabled(true);
        jf.setAcceptAllFileFilterUsed(true);
        jf.setFileFilter( new FileFilter(){
            @Override
            public boolean accept(File f) {
                if( f.getName().endsWith(".obj"))
                    return true;
                else
                    return false;            
            }
            @Override
            public String getDescription() {
                return "OBJ files";
            }
        });
        aiAttachLogStream(
                aiGetPredefinedLogStream(aiDefaultLogStream_STDOUT, ""));
        if (jf.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            File[] selected = jf.getSelectedFiles();
            for (File f : selected) {
                String fullpath = f.getAbsolutePath();
                aiScene scene = aiImportFile(fullpath,
                        aiProcess_CalcTangentSpace
                        | aiProcess_Triangulate
                        | aiProcess_JoinIdenticalVertices
                        | aiProcess_SortByPType
                        | aiProcess_GenSmoothNormals
                        | aiProcess_LimitBoneWeights
                        | aiProcess_OptimizeMeshes
                        | aiProcess_FindInvalidData
                        | aiProcess_PreTransformVertices
                );
                if (scene == null) {
                    System.out.println("Not imported");
                    System.exit(1);
                }

                aiMesh[] MS = scene.getMeshes();
                int numv=0;
                int numi=0;
                for(aiMesh M: MS ){
                    if( M.mPrimitiveTypes != aiPrimitiveType_TRIANGLE )
                        continue;
                    numv += M.mNumVertices;
                    numi += M.mNumFaces*3;
                }
                
                ByteBuffer positionsAsBytes = ByteBuffer.allocate(4*numv*3);
                positionsAsBytes.order(ByteOrder.nativeOrder());
                FloatBuffer positionsAsFloats = positionsAsBytes.asFloatBuffer();
                
                ByteBuffer normalsAsBytes = ByteBuffer.allocate(4*numv*3);
                normalsAsBytes.order(ByteOrder.nativeOrder());
                FloatBuffer normalsAsFloats = normalsAsBytes.asFloatBuffer();
                
                ByteBuffer indicesAsBytes = ByteBuffer.allocate(numi*4);
                indicesAsBytes.order(ByteOrder.nativeOrder());
                IntBuffer indicesAsInts = indicesAsBytes.asIntBuffer();

                //material info: One material index per vertex.
                ByteBuffer vertexMaterialsAsBytes = ByteBuffer.allocate(numv*4);
                vertexMaterialsAsBytes.order(ByteOrder.nativeOrder());
                FloatBuffer vertexMaterialsAsFloats = vertexMaterialsAsBytes.asFloatBuffer();
                
                int delta=0;
                
                for(aiMesh M : MS ){
                    if( M.mPrimitiveTypes != aiPrimitiveType_TRIANGLE )
                        continue;

                    aiVector3D[] V = M.getVertices();
                    aiVector3D[] N = M.getNormals();
                    for(int i=0;i<V.length;++i){
                        positionsAsFloats.put(V[i].x);
                        positionsAsFloats.put(V[i].y);
                        positionsAsFloats.put(V[i].z);
                        vertexMaterialsAsFloats.put(M.mMaterialIndex);
                        normalsAsFloats.put(N[i].x);
                        normalsAsFloats.put(N[i].y);
                        normalsAsFloats.put(N[i].z);
                    }
                    for( aiFace F : M.getFaces() ){
                        int[] I = F.getIndices();
                        indicesAsInts.put(I[0]+delta);
                        indicesAsInts.put(I[1]+delta);
                        indicesAsInts.put(I[2]+delta);
                    }
                    delta += M.mNumVertices;
                }
                
                System.out.println("numv: "+numv);
                System.out.println("numi: "+numi);
                
                String outfilename = fullpath+".mesh";
                RandomAccessFile out = new RandomAccessFile(outfilename,"rw");
                out.setLength(0);
                out.writeUTF("mesh4a");
                out.writeUTF("num_vertices");
                out.writeInt(numv);
                out.writeUTF("num_indices");
                out.writeInt(numi);
                out.writeUTF("positions");
                out.write(positionsAsBytes.array());
                out.writeUTF("normals");
                out.write(normalsAsBytes.array());
                out.writeUTF("indices");
                out.write(indicesAsBytes.array());
                out.writeUTF("vertexMaterials");
                out.write(vertexMaterialsAsBytes.array());
                
                out.writeUTF("num_materials");
                out.writeInt(scene.mNumMaterials);
                aiMaterial[] ML = scene.getMaterials();
                for(int i=0;i<ML.length;++i){
                    aiMaterial mtl = ML[i];
                    aiColor4D col = new aiColor4D();
                    out.writeUTF("material");
                    out.writeInt(i);
                    out.writeUTF( aiGetMaterialString(mtl, AI_MATKEY_NAME));
                    aiGetMaterialColor(mtl, AI_MATKEY_COLOR_DIFFUSE,0,0,col);
                    out.writeUTF("diffuse");
                    out.writeFloat(col.r);
                    out.writeFloat(col.g);
                    out.writeFloat(col.b);
                    aiGetMaterialColor(mtl, AI_MATKEY_COLOR_SPECULAR,0,0,col);
                    float[] flt = new float[1];
                    aiGetMaterialFloat(mtl,AI_MATKEY_SHININESS,0,0,flt);
                    if( flt[0] == 0 ){
                        //a shininess value of zero doesn't make much sense
                        flt[0]=1.0f;
                    }
                    else{
                        //put it into a more reasonable range
                        //This number was determined by what looked "good"
                        //for some definition of "good"...
                        flt[0] /= 7.68;
                    }
                    out.writeUTF("specular");
                    out.writeFloat(col.r);
                    out.writeFloat(col.g);
                    out.writeFloat(col.b);
                    out.writeUTF("shininess");
                    out.writeFloat(flt[0]);
                }
                
                out.writeUTF("endMaterials");
                
                out.writeUTF("end");

                out.close();
                System.out.println("Wrote "+outfilename);
            }
            
        }
        System.exit(0);
    }
}
