/*
 */
package javaapplication1;

import java.io.*;
import static etgg.GL.*;
import java.nio.file.Path;
import math3d.vec3;

/**
 *
 * @author jhudson
 */
public class Mesh {

    int numv;
    int numi;
    int vao;

    static final int MAX_MATERIALS = 16;
    static final int MAX_TEXTURES = 4;
    vec3[] diffuseColors = new vec3[MAX_MATERIALS];
    vec3[] specularColors = new vec3[MAX_MATERIALS];
    float[] shininess = new float[MAX_MATERIALS];
    int[] materialDiffuseTextureIndex = new int[MAX_MATERIALS];
    //int[] usedTextures = new int[MAX_MATERIALS];

    public Mesh(String filename) {
        init(filename);
    }

    public Mesh(Path p) {
        init(p.toString());
    }

    void init(String filename) {
        try {
            RandomAccessFile raf = new RandomAccessFile(filename, "r");
            File tmpf = new File(filename);
            String basedir = tmpf.getParent();

            String line = raf.readUTF();
            if (!line.equals("mesh4a")) {
                throw new RuntimeException("Bad mesh format for " + filename + ": Got " + line);
            }
            int[] tmp = new int[1];
            glGenVertexArrays(1, tmp);
            vao = tmp[0];
            glBindVertexArray(vao);

            line = raf.readUTF();
            if (!line.equals("num_vertices")) {
                throw new RuntimeException("Unexpected");
            } else {
                numv = raf.readInt();
            }

            line = raf.readUTF();
            if (!line.equals("num_indices")) {
                throw new RuntimeException("Unexpected");
            } else {
                numi = raf.readInt();
            }

            line = raf.readUTF();
            if (!line.equals("positions")) {
                throw new RuntimeException("Unexpected");
            } else {
                byte[] data = new byte[numv * 3 * 4];
                raf.readFully(data);
                glGenBuffers(1, tmp);
                glBindBuffer(GL_ARRAY_BUFFER, tmp[0]);
                glBufferData(GL_ARRAY_BUFFER, data.length, data, GL_STATIC_DRAW);
                glVertexAttribPointer(Program.POSITION_INDEX, 3, GL_FLOAT, false, 3 * 4, 0);
                glEnableVertexAttribArray(Program.POSITION_INDEX);
            }

            line = raf.readUTF();
            if (!line.equals("normals")) {
                throw new RuntimeException("Unexpected");
            } else {
                byte[] data = new byte[numv * 3 * 4];
                raf.readFully(data);
                glGenBuffers(1, tmp);
                glBindBuffer(GL_ARRAY_BUFFER, tmp[0]);
                glBufferData(GL_ARRAY_BUFFER, data.length, data, GL_STATIC_DRAW);
                glVertexAttribPointer(Program.NORMAL_INDEX, 3, GL_FLOAT, false, 3 * 4, 0);
                glEnableVertexAttribArray(Program.NORMAL_INDEX);
            }

            line = raf.readUTF();
            if (!line.equals("indices")) {
                throw new RuntimeException("Unexpected");
            } else {
                byte[] data = new byte[numi * 4];
                raf.readFully(data);
                glGenBuffers(1, tmp);
                glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, tmp[0]);
                glBufferData(GL_ELEMENT_ARRAY_BUFFER, data.length, data, GL_STATIC_DRAW);
            }

            line = raf.readUTF();
            if (!line.equals("vertexMaterials")) {
                throw new RuntimeException("Unexpected");
            } else {
                byte[] data = new byte[numv * 4];
                raf.readFully(data);
                glGenBuffers(1, tmp);
                glBindBuffer(GL_ARRAY_BUFFER, tmp[0]);
                glBufferData(GL_ARRAY_BUFFER, data.length, data, GL_STATIC_DRAW);
                glVertexAttribPointer(Program.MATERIAL_INDEX, 1, GL_FLOAT, false, 1 * 4, 0);
                glEnableVertexAttribArray(Program.MATERIAL_INDEX);
            }

            line = raf.readUTF();
            if (!line.equals("num_materials")) {
                throw new RuntimeException("Unexpected");
            }

            int numm = raf.readInt();
            if (numm > MAX_MATERIALS) {
                System.out.println("Too many materials!");
                System.exit(1);
            }
            for (int i = 0; i < numm; ++i) {
                line = raf.readUTF();
                if (!line.equals("material")) {
                    throw new RuntimeException("Expected material");
                }

                int mi = raf.readInt();
                String name = raf.readUTF();
                String what = raf.readUTF();
                if (!what.equals("diffuse")) {
                    throw new RuntimeException("Expected diffuse, got " + what);
                }
                diffuseColors[mi] = new vec3(
                        raf.readFloat(),
                        raf.readFloat(),
                        raf.readFloat()
                );
                what = raf.readUTF();
                if (!what.equals("specular")) {
                    throw new RuntimeException("Expected specular, got " + what);
                }
                specularColors[mi] = new vec3(
                        raf.readFloat(),
                        raf.readFloat(),
                        raf.readFloat()
                );
                what = raf.readUTF();
                if (!what.equals("shininess")) {
                    throw new RuntimeException("Expected shininess, got " + what);
                }
                shininess[mi] = raf.readFloat();

            }

            line = raf.readUTF();
            if (!line.equals("endMaterials")) {
                throw new RuntimeException("End materials");
            }

            line = raf.readUTF();
            if (!line.equals("end")) {
                throw new RuntimeException("Unexpected");
            }

            glBindVertexArray(0);

        } catch (IOException ex) {
            System.out.println("I/O error for " + filename + ": " + ex);
            System.exit(1);
        }
        for (int i = 0; i < diffuseColors.length; ++i) {
            if (diffuseColors[i] == null) {
                diffuseColors[i] = new vec3(0, 0, 0);
            }
        }
        for (int i = 0; i < specularColors.length; ++i) {
            if (specularColors[i] == null) {
                specularColors[i] = new vec3(0, 0, 0);
            }
        }

    }

    public void draw() {
        glBindVertexArray(vao);
        Program.current.setUniform("diffuse[0]", diffuseColors);
        Program.current.setUniform("specular[0]", specularColors);
        Program.current.setUniform("shininess[0]", shininess);
        glDrawElements(GL_TRIANGLES, numi, GL_UNSIGNED_INT, 0);
    }
}
