/*
 */
package javaapplication1;
import static etgg.GL.*;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import math3d.mat4;
import math3d.vec3;
import math3d.vec4;

/**
 *
 * @author jhudson
 */
public class Program {
    int prog;
    String identifier;
    static Program current;
    static int POSITION_INDEX = 0;
    static int MATERIAL_INDEX = 1;
    static int NORMAL_INDEX = 2;
    
    Map<String,Setter> uniforms = new TreeMap<>();
    
    abstract class Setter{
        String name;
        int loc;
        Setter(String n, int l){
            name=n;
            loc=l;
        }
        abstract void set(Object o);
    }
    class mat4Setter extends Setter{
        mat4Setter(String n, int l) {
            super(n,l);
        }
        @Override
        void set(Object o){
            mat4 m = (mat4) o;
            glUniformMatrix4fv(loc,1,true,m._M);
        }
    }
    class floatSetter extends Setter {
        floatSetter(String n, int loc){
            super(n,loc);
        }
        @Override
        void set(Object o){
            Number v = (Number) o;
            glUniform1f(loc,v.floatValue());
        }
    }
    class vec3Setter extends Setter {
        vec3Setter(String n, int loc){
            super(n,loc);
        }
        @Override
        void set(Object o){
            vec3 v = (vec3) o;
            glUniform3f(loc,v.x,v.y,v.z);
        }
    }
    class vec4Setter extends Setter {
        vec4Setter(String n, int loc){
            super(n,loc);
        }
        @Override
        void set(Object o){
            vec4 v = (vec4) o;
            glUniform4f(loc,v.x,v.y,v.z,v.w);
        }
    }
    class vec3ArraySetter extends Setter {
        int size;
        vec3ArraySetter(String n, int loc, int size){
            super(n,loc);
            this.size=size;
        }
        @Override
        void set(Object o){
            vec3[] v = (vec3[]) o;
            if( v.length != size ){
                throw new RuntimeException("Uniform "+name+": Should have "+size+" elements, but it had "+v.length+" elements");
            }
            float[] tmp = new float[size*3];
            for(int i=0,j=0;i<size;i++){
                tmp[j++] = v[i].x;
                tmp[j++] = v[i].y;
                tmp[j++] = v[i].z;
            }
            glUniform3fv(loc,size,tmp);
        }
    }

    class intArraySetter extends Setter {
        int size;
        intArraySetter(String n, int loc, int size){
            super(n,loc);
            this.size=size;
        }
        @Override
        void set(Object o){
            int[] v = (int[]) o;
            if( v.length != size ){
                throw new RuntimeException("Uniform "+name+": Should have "+size+" elements, but it had "+v.length+" elements");
            }
            glUniform1iv(loc,size,v);
        }
    }
    class floatArraySetter extends Setter {
        int size;
        floatArraySetter(String n, int loc, int size){
            super(n,loc);
            this.size=size;
        }
        @Override
        void set(Object o){
            float[] v = (float[]) o;
            if( v.length != size ){
                throw new RuntimeException("Uniform "+name+": Should have "+size+" elements, but it had "+v.length+" elements");
            }
            glUniform1fv(loc,size,v);
        }
    }

        
    public Program(String vsfname, String fsfname){
        identifier = vsfname+"+"+fsfname;
        int vs = compile(vsfname,GL_VERTEX_SHADER);
        int fs = compile(fsfname,GL_FRAGMENT_SHADER);
        prog = glCreateProgram();
        glAttachShader(prog, vs);
        glAttachShader(prog, fs);

        bindAttributeLocations();
        link();
        setupUniformSetters();
    }
    
    void bindAttributeLocations(){
        glBindAttribLocation(prog, POSITION_INDEX, "position");
        glBindAttribLocation(prog, MATERIAL_INDEX, "materialIndex");
        glBindAttribLocation(prog, NORMAL_INDEX, "normal");
    }
    void link(){
        glLinkProgram(prog);
        int[] length = new int[1];
        byte[] infolog = new byte[4096];
        glGetProgramInfoLog(prog, infolog.length, length, infolog);
        if( length[0] > 0 ){
            String tmp = new String(infolog,0,length[0]);
            System.out.println("When compiling "+identifier+":");
            System.out.println(tmp);
        }
        int[] status = new int[1];
        glGetProgramiv(prog,GL_LINK_STATUS,status);
        if( status[0] == 0 ){
            throw new RuntimeException("Could not link "+identifier);
        }
    }
    
    void setupUniformSetters(){
        int[] tmp = new int[1];
        glGetProgramiv(prog,GL_ACTIVE_UNIFORMS, tmp);
        int numuniforms = tmp[0];
        int unit=0;
        for(int i=0;i<numuniforms;++i){
            int[] idx = new int[]{i};
            glGetActiveUniformsiv(prog,1,idx,GL_UNIFORM_TYPE,tmp);
            int type=tmp[0];
            glGetActiveUniformsiv(prog,1,idx,GL_UNIFORM_SIZE,tmp);
            int size = tmp[0];
            byte[] namea = new byte[256];
            glGetActiveUniformName(prog,i,namea.length,tmp, namea);
            int len = tmp[0];
            String name = new String(namea,0,len);
            int loc = glGetUniformLocation(prog,name);
            if (type == GL_FLOAT_MAT4 && size == 1){
                uniforms.put(name,new mat4Setter(name,loc));
            }
            else if (type == GL_FLOAT_VEC3 && size == 1){
                uniforms.put(name,new vec3Setter(name,loc));
            }
            else if (type == GL_FLOAT_VEC4 && size == 1){
                uniforms.put(name,new vec4Setter(name,loc));
            }
            else if( type == GL_FLOAT_VEC3 && size > 1 ){
                uniforms.put(name,new vec3ArraySetter(name, loc, size));
            }
            else if( type == GL_FLOAT && size == 1 ){
                uniforms.put(name,new floatSetter(name, loc));
            }
            else if( type == GL_INT && size > 1 ){
                uniforms.put(name,new intArraySetter(name, loc, size));
            }
            else if( type == GL_FLOAT && size > 1 ){
                uniforms.put(name,new floatArraySetter(name, loc, size));
            }
            else
                throw new RuntimeException( "Don't know about type of "+name);
        }
    }
    public void use(){
        glUseProgram(prog);
        current = this;
    }
    Set<String> warned = new TreeSet<>();
    public void setUniform(String name, Object value){
        if( current != this )
            throw new RuntimeException("Cannot set uniform on non-active program");
        if( !uniforms.containsKey(name)){
            if( !warned.contains(name)){
                warned.add(name);
                System.out.println("Warning: No such uniform "+name+" in "+identifier);
                //Antibugging: Include this!
                if( uniforms.containsKey(name+"[0]")){
                    throw new RuntimeException("Use uniform name '"+name+"[0]', not '"+name+"'");
                }
            }
            return;
        }
        uniforms.get(name).set(value);
    }
     
   
    int compile(String fname, int type){
        int s = glCreateShader(type);
        String[] fdata = new String[1];
        int[] length = new int[1];
        try {
            fdata[0] = new String(Files.readAllBytes(FileSystems.getDefault().getPath(fname)));
        } catch (IOException ex) {
            System.out.println("Could not read file "+fname);
            throw new RuntimeException();
        }
        length[0] = fdata[0].length();
        glShaderSource(s,1,fdata,length);
        glCompileShader(s);
        byte[] infolog = new byte[4096];
        glGetShaderInfoLog(s, infolog.length, length, infolog);
        if( length[0] > 0 ){
            String tmp = new String(infolog,0,length[0]);
            System.out.println("When compiling "+fname+":");
            System.out.println(tmp);
        }
        int[] status = new int[1];
        glGetShaderiv(s,GL_COMPILE_STATUS,status);
        if( status[0] == 0 ){
            throw new RuntimeException("Could not compile "+fname);
        }
        return s;
    }
}
