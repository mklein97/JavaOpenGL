#version 150

#define MAX_MATERIALS 16

uniform vec3 diffuse[MAX_MATERIALS];
uniform vec3 specular[MAX_MATERIALS];
uniform float shininess[MAX_MATERIALS];
uniform vec4 lightPosition;     //w: 1=positional, 0=directional
uniform vec4 lightColor;    
uniform vec3 eyePos;

in vec3 v_normal;
in vec3 v_worldPosition;
flat in int v_materialIndex;

out vec4 color;

void main(){
    vec3 L = normalize(lightPosition.xyz - lightPosition.w * v_worldPosition);
    vec3 N = normalize(v_normal);
    vec3 V = normalize(eyePos-v_worldPosition);
    vec3 R = reflect(-L,N);
    float dp = dot(L,N);
    dp = max(0.0,dp);
    float sp = dot(V,R);
    sp = max(0.0,sp);
    sp = pow(sp,shininess[v_materialIndex]);
    color.rgb = lightColor.rgb * (dp * diffuse[v_materialIndex] + sp * specular[v_materialIndex]);
    color.a = 1.0;
}
