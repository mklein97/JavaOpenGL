package chess;

public class Point {
    public int col = 0;
    public int row = 0;
    
    public Point(int row, int col) {
        this.row = row;
        this.col = col;
    }
}