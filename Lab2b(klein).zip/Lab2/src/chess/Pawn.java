package chess;

public class Pawn extends Piece {

    public Pawn(int r, int c, boolean white) {
        super(r, c, white);
    }

    @Override
    public Point[] get_valid_moves(Piece[] all_pieces) {
        Point[] points = new Point[64];
        int n = 0;

        //Diagonal
        if (get_occupied(all_pieces, myRow + 1, myColumn + 1)) {
            points[n] = new Point(myRow+1, myColumn+1);
            n++;
        }
        if (get_occupied(all_pieces, myRow + 1, myColumn - 1)) {
            points[n] = new Point(myRow+1, myColumn-1);
            n++;
        }
        
            //move forward 1
            if (!get_occupied(all_pieces, myRow + 1, myColumn)) {
                points[n] = new Point(myRow+1, myColumn);
                n++;
            }
        
        if (!hasMoved) {
            //move forward 2
            if (!get_occupied(all_pieces, myRow + 2, myColumn)) {
                points[n] = new Point(myRow + 2, myColumn);
                n++;
            }
        }
        Point[] point_list = new Point[n];
        System.arraycopy(points, 0, point_list, 0, n);
        return point_list;
    }
}
