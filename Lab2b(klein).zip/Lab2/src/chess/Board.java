package chess;

import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;



public class Board{
    Piece[] allpieces = new Piece[32];
    
    //white pawns
    Pawn wp1 = new Pawn(2,1,true);
    Pawn wp2 = new Pawn(2,2,true);
    Pawn wp3 = new Pawn(2,3,true);
    Pawn wp4 = new Pawn(2,4,true);
    Pawn wp5 = new Pawn(2,5,true);
    Pawn wp6 = new Pawn(2,6,true);
    Pawn wp7 = new Pawn(2,7,true);
    Pawn wp8 = new Pawn(2,8,true);
    //black pawns
    Pawn bp1 = new Pawn(7,1,false);
    Pawn bp2 = new Pawn(7,2,false);
    Pawn bp3 = new Pawn(7,3,false);
    Pawn bp4 = new Pawn(7,4,false);
    Pawn bp5 = new Pawn(7,5,false);
    Pawn bp6 = new Pawn(7,6,false);
    Pawn bp7 = new Pawn(7,7,false);
    Pawn bp8 = new Pawn(7,8,false);
    //white rooks
    Rook wr1 = new Rook(1,1,true);
    Rook wr2 = new Rook(1,8,true);
    //black rooks
    Rook br1 = new Rook(8,1,false);
    Rook br2 = new Rook(8,8,false);
    //white knights
    Knight wk1 = new Knight(1,2,true);
    Knight wk2 = new Knight(1,7,true);
    //black knights
    Knight bk1 = new Knight(8,2,false);
    Knight bk2 = new Knight(8,7,false);
    //white bishops
    Bishop wb1 = new Bishop(1,3,true);
    Bishop wb2 = new Bishop(1,6,true);
    //black bishops
    Bishop bb1 = new Bishop(8,3,false);
    Bishop bb2 = new Bishop(8,6,false);
    //white king
    King wking = new King(1,4,true);
    //black king
    King bking = new King(8,4,false);
    //white queen
    Queen wqueen = new Queen(1,5,true);
    //black queen
    Queen bqueen = new Queen(8,5,true);
    
    Piece[] masterlist = {wp1,wp2,wp3,wp4,wp5,wp6,wp7,wp8,bp1,bp2,bp3,bp4,bp5,bp6,bp7,bp8,wr1,wr2,br1,br2,wk1,wk2,bk1,bk2,wb1,wb2,bb1,bb2,wking,bking,wqueen,bqueen};
    
    public void drawBoard(GameContainer gc, Graphics g){
   
        //first row (starting from bottom)
        g.setColor(Color.gray);
        g.fillRect(0, 350, 50, 50);
        g.fillRect(100, 350, 50, 50);
        g.fillRect(200, 350, 50, 50);
        g.fillRect(300, 350, 50, 50);
        g.fillRect(400, 350, 50, 50);
        g.setColor(Color.white);
        g.fillRect(50, 350, 50, 50);
        g.fillRect(150, 350, 50, 50);
        g.fillRect(250, 350, 50, 50);
        g.fillRect(350, 350, 50, 50);
        //second row
        g.fillRect(0, 300, 50, 50);
        g.fillRect(100, 300, 50, 50);
        g.fillRect(200, 300, 50, 50);
        g.fillRect(300, 300, 50, 50);
        g.fillRect(400, 300, 50, 50);
        g.setColor(Color.gray);
        g.fillRect(50, 300, 50, 50);
        g.fillRect(150, 300, 50, 50);
        g.fillRect(250, 300, 50, 50);
        g.fillRect(350, 300, 50, 50);
        //third row
        g.fillRect(0, 250, 50, 50);
        g.fillRect(100, 250, 50, 50);
        g.fillRect(200, 250, 50, 50);
        g.fillRect(300, 250, 50, 50);
        g.fillRect(400, 250, 50, 50);
        g.setColor(Color.white);
        g.fillRect(50, 250, 50, 50);
        g.fillRect(150, 250, 50, 50);
        g.fillRect(250, 250, 50, 50);
        g.fillRect(350, 250, 50, 50);
        //fourth row
        g.fillRect(0, 200, 50, 50);
        g.fillRect(100, 200, 50, 50);
        g.fillRect(200, 200, 50, 50);
        g.fillRect(300, 200, 50, 50);
        g.fillRect(400, 200, 50, 50);
        g.setColor(Color.gray);
        g.fillRect(50, 200, 50, 50);
        g.fillRect(150, 200, 50, 50);
        g.fillRect(250, 200, 50, 50);
        g.fillRect(350, 200, 50, 50);
        //fifth row
        g.fillRect(0, 150, 50, 50);
        g.fillRect(100, 150, 50, 50);
        g.fillRect(200, 150, 50, 50);
        g.fillRect(300, 150, 50, 50);
        g.fillRect(400, 150, 50, 50);
        g.setColor(Color.white);
        g.fillRect(50, 150, 50, 50);
        g.fillRect(150, 150, 50, 50);
        g.fillRect(250, 150, 50, 50);
        g.fillRect(350, 150, 50, 50);
        //sixth row
        g.fillRect(0, 100, 50, 50);
        g.fillRect(100, 100, 50, 50);
        g.fillRect(200, 100, 50, 50);
        g.fillRect(300, 100, 50, 50);
        g.fillRect(400, 100, 50, 50);
        g.setColor(Color.gray);
        g.fillRect(50, 100, 50, 50);
        g.fillRect(150, 100, 50, 50);
        g.fillRect(250, 100, 50, 50);
        g.fillRect(350, 100, 50, 50);
        //seventh row
        g.fillRect(0, 50, 50, 50);
        g.fillRect(100, 50, 50, 50);
        g.fillRect(200, 50, 50, 50);
        g.fillRect(300, 50, 50, 50);
        g.fillRect(400, 50, 50, 50);
        g.setColor(Color.white);
        g.fillRect(50, 50, 50, 50);
        g.fillRect(150, 50, 50, 50);
        g.fillRect(250, 50, 50, 50);
        g.fillRect(350, 50, 50, 50);
        //eighth row
        g.fillRect(0, 0, 50, 50);
        g.fillRect(100, 0, 50, 50);
        g.fillRect(200, 0, 50, 50);
        g.fillRect(300, 0, 50, 50);
        g.fillRect(400, 0, 50, 50);
        g.setColor(Color.gray);
        g.fillRect(50, 0, 50, 50);
        g.fillRect(150, 0, 50, 50);
        g.fillRect(250, 0, 50, 50);
        g.fillRect(350, 0, 50, 50);
    }
    }