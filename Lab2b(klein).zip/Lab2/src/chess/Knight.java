package chess;

import klein.Lab2b;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;

public class Knight extends Piece {

    public Knight(int r, int c, boolean white) {
        super(r, c, white);
    }

    @Override
    public Point[] get_valid_moves(Piece[] all_pieces) {
        Point[] points = new Point[8];
        int n = 0;

        //point1
        if (!get_occupied(all_pieces, myRow + 2, myColumn - 1)) {
            points[n] = new Point(myRow + 2, myColumn - 1);
            n++;
        }

        //point2
        if (!get_occupied(all_pieces, myRow + 2, myColumn + 1)) {
            points[n] = new Point(myRow + 2, myColumn + 1);
            n++;
        }
        
        //point3
        if (!get_occupied(all_pieces, myRow + 1, myColumn + 2)) {
            points[n] = new Point(myRow + 1, myColumn + 2);
            n++;
        }
        
        //point4
        if (!get_occupied(all_pieces, myRow - 1, myColumn + 2)) {
            points[n] = new Point(myRow - 1, myColumn + 2);
            n++;
        }
        
        //point5
        if (!get_occupied(all_pieces, myRow - 2, myColumn + 1)) {
            points[n] = new Point(myRow - 2, myColumn + 1);
            n++;
        }
        
        //point6
        if (!get_occupied(all_pieces, myRow - 2, myColumn - 1)) {
            points[n] = new Point(myRow - 2, myColumn - 1);
            n++;
        }
        
        //point7
        if (!get_occupied(all_pieces, myRow - 1, myColumn - 2)) {
            points[n] = new Point(myRow - 1, myColumn - 2);
            n++;
        }
        
        //point8
        if (!get_occupied(all_pieces, myRow + 1, myColumn - 2)) {
            points[n] = new Point(myRow + 1, myColumn - 2);
            n++;
        }
        Point[] point_list = new Point[n];
        System.arraycopy(points, 0, point_list, 0, n);
        return point_list;
    }
    public void draw(GameContainer gc, Graphics g){
        g.drawImage(Lab2b.mImage, 50, 350, 100, 400, 200, 150, 250, 200);
    }
}