package klein;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.KeyListener;
import org.newdawn.slick.MouseListener;
import org.newdawn.slick.SlickException;

import chess.*;

public class Lab2b extends BasicGame implements KeyListener, MouseListener
{
    public static Image mImage;
    Board board = new Board();
    Rook rook = new Rook(1,1,false);
    
    public Lab2b(String gamename)
    {
        super(gamename);
    }

    @Override
    public void init(GameContainer gc) throws SlickException 
    {
        mImage = new Image("pieces.png");
        gc.setShowFPS(false);
    }

    @Override
    public void update(GameContainer gc, int i) throws SlickException 
    {
    
    }
    
    
    @Override
    public void keyPressed(int k, char c)
    {
       
    }
    
    
    public void mousePressed(int x, int y)
    {
        
    }
    
    

    @Override
    public void render(GameContainer gc, Graphics g) throws SlickException
    {
        board.drawBoard(gc,g);
        rook.draw(gc,g);
        
    }

    public static void main(String[] args)
    {
        try
        {
            AppGameContainer appgc;
            appgc = new AppGameContainer(new Lab2b("Lab2b Chess"));
            appgc.setDisplayMode(400, 400, false);
            appgc.start();
        }
        catch (SlickException ex)
        {
            Logger.getLogger(Lab2b.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}