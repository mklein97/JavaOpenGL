Slick - A 2D LWJGL Java Utility Library
-----------------------------------------------------------

This is a very early version. The tests work but no demo has been written yet. All the natives
are included in the main distribution in the right place. This is just meant to make it easier for quick
start users. All the natives required can be found in jars in the 'lib' directory.


Tools
~~~~~

AngelCode bitmap font tool - seems to be the best around at the moment and provided clean kerning 
                             information. Available from http://www.angelcode.com/products/bmfont/.
TilED tile map tool        - Java alternative to Mappy (which just seems borked to me). Available
	  						 from http://www.mapeditor.org.
ImagePacker				   - ImagePacker (http://homepage.ntlworld.com/config/imagepacker/index.htm) packs
							 single images into large images for efficent rendering and memory usage.	
Pedigree 				   - Particle Editor written as part of the Slick Project (Java)
Hiero					   - Bitmap Font tool with effects written as part fo the Slick Project (Java)							 				 