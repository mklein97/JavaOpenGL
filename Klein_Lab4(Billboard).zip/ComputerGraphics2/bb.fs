//Fragment Shader
in vec2 g_texCoord;
uniform sampler2DArray textures;
out vec4 color;

void main() {
	color = texture(textures, vec3(g_texCoord, texFrameNumber));
	if (color.a < 0.01)
		discard;
}