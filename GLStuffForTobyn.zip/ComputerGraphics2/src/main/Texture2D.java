/*
 */
package main;

import static etgg.GL.GL_TEXTURE_2D;

/**
 *
 * @author jhudson
 */
public class Texture2D extends Texture{
    int w,h;
    Texture2D(){
        super(GL_TEXTURE_2D);
    }
}
