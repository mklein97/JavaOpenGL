uniform sampler2DArray tex;
uniform sampler2DArray shadowBuffer;

in vec2 v_texCoord;
out vec4 color;

void main() {
	vec4 s0 = texture(tex, vec3(v_texCoord, 0));
	vec4 s1 = texture(tex, vec3(v_texCoord, 1));
	vec4 s2 = texture(tex, vec3(v_texCoord, 2));
	vec4 s3 = texture(tex, vec3(v_texCoord, 3));
	vec4 s4 = texture(tex, vec3(v_texCoord, 4));
	
	vec3 worldPos = s0.xyz;
	vec3 N = s1.xyz;
	vec3 L = lightPosition.xyz - worldPos;
	L = normalize(L);
	vec3 V = normalize(eyePos - worldPos);
	vec3 R = reflect(-L, N);
	float dp = dot(L,N);
	dp = max(0.0, dp);
	float sp = 0.0;
	if (dp > 0.0) {
		sp = dot(V,R);
		sp = max(0.0, sp);
		sp = pow(sp, s4.a);
	}
	color.rgb = vec3(0,0,0);
	
	color.rgb = s2.rgb * dp * lightColor;
	color.rgb += sp * s4.rgb * lightColor;
	color.rgb += s3.rgb * blurColorScale;
	float fogDistance = distance(eyePos,worldPos);
    float fogAmt = clamp( (fogDistance - fogNear) / fogDelta, 0, 1 );
    color.rgb = mix( color.rgb, fogColor, fogAmt );
	
	//shadow
	vec4 p=vec4(worldPos,1);
	p*=lightViewMatrix;//set by draw2()
	float dist1=(-p.z - lightHitherYon[0]) / lightHitherYon[2];
	p*=lightProjMatrix;
	p/=p.w;
	p.xy+=vec2(1,1);
	p.xy*=0.5;
	float dist2=texture(shadowBuffer,vec3(p.xy,0)).r;
	if(p.x<0||p.x>1||p.y<0||p.y>1||dist1>dist2+bias)
		color.rgb *= 0.35;
	
	color.a = 1.0;
		if( dot(N,N) == 0.0 ){
		color.rgb = s2.rgb + s3.rgb;
		color.a = 1.0;
		return;
	}
	//color.rgb = vec3(dist1);
	//color.rgb = vec3(lightPosition);
}