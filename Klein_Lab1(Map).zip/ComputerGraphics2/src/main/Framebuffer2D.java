package main;

import etgg.GL;
import static etgg.GL.GL_CLAMP_TO_EDGE;
import static etgg.GL.GL_COLOR_ATTACHMENT0;
import static etgg.GL.GL_DEPTH24_STENCIL8;
import static etgg.GL.GL_DEPTH_STENCIL;
import static etgg.GL.GL_DEPTH_STENCIL_ATTACHMENT;
import static etgg.GL.GL_FRAMEBUFFER;
import static etgg.GL.GL_LINEAR;
import static etgg.GL.GL_NEAREST;
import static etgg.GL.GL_RGBA;
import static etgg.GL.GL_TEXTURE_2D_ARRAY;
import static etgg.GL.GL_TEXTURE_MAG_FILTER;
import static etgg.GL.GL_TEXTURE_MIN_FILTER;
import static etgg.GL.GL_TEXTURE_WRAP_S;
import static etgg.GL.GL_TEXTURE_WRAP_T;
import static etgg.GL.GL_UNSIGNED_BYTE;
import static etgg.GL.GL_UNSIGNED_INT_24_8;
import static etgg.GL.GL_VIEWPORT;
import static etgg.GL.glBindFramebuffer;
import static etgg.GL.glDrawBuffers;
import static etgg.GL.glFramebufferTextureLayer;
import static etgg.GL.glGenFramebuffers;
import static etgg.GL.glGenTextures;
import static etgg.GL.glGetIntegerv;
import static etgg.GL.glTexImage3D;
import static etgg.GL.glTexParameteri;
import static etgg.GL.glViewport;

/**
 *
 * @author jhudson
 */
public class Framebuffer2D {

    Texture2DArray tex;
    Texture2DArray dtex;
    int fbo;
    int[] drawbuffers;
    int[] saved_viewport = new int[4];
    static Framebuffer2D active_fbo;
    
    public Framebuffer2D(int width, int height, int format){
        tex = new Texture2DArray();
        tex.owning_fbo = this;
        tex.w = width;
        tex.h = height;
        tex.slices = 1;
        int[] tmp = new int[1];
        glGenTextures(1, tmp);
        tex.tex = tmp[0];
        tex.bind(0);
        glTexImage3D(GL_TEXTURE_2D_ARRAY, 
                0,      //mip level
                format, 
                width,height,tex.slices,0,GL_RGBA,GL_UNSIGNED_BYTE,(byte[])null);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        tex.unbind(0);
        
        
        dtex = new Texture2DArray();
        dtex.owning_fbo = this;
        dtex.w = width;
        dtex.h = height;
        dtex.slices = 1;
        glGenTextures(1, tmp);
        dtex.tex = tmp[0];
        dtex.bind(0);
        glTexImage3D(GL_TEXTURE_2D_ARRAY, 
                0,      //mip level
                GL_DEPTH24_STENCIL8, 
                width,height,dtex.slices,0,GL_DEPTH_STENCIL,GL_UNSIGNED_INT_24_8,(byte[])null);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        dtex.unbind(0);
        
        glGenFramebuffers(1,tmp);
        fbo = tmp[0];
        glBindFramebuffer(GL.GL_FRAMEBUFFER,fbo);
        //second to last 0 = mip level
        //last number = texture layer (slice number)
        glFramebufferTextureLayer(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,tex.tex,0,0);
        glFramebufferTextureLayer(GL_FRAMEBUFFER,GL_DEPTH_STENCIL_ATTACHMENT,dtex.tex,0,0);
        
        int complete = GL.glCheckFramebufferStatus(GL_FRAMEBUFFER);
        if( complete != GL.GL_FRAMEBUFFER_COMPLETE )
            throw new RuntimeException("Your framebuffer is incomplete. Fix something.");

        drawbuffers = new int[]{ GL_COLOR_ATTACHMENT0 };
        glBindFramebuffer(GL_FRAMEBUFFER,0);
    }
    
    public void bind(){
        //tell GL we want to render to this FBO
        if( !tex.on_units.isEmpty()) 
            throw new RuntimeException("Cannot write to an FBO with active textures");
        
        if( active_fbo == this )
            return;
        if( active_fbo != null )
            active_fbo.unbind();
        glBindFramebuffer(GL_FRAMEBUFFER, fbo);
        glDrawBuffers(drawbuffers.length, drawbuffers);
        glGetIntegerv(GL_VIEWPORT, saved_viewport);
        glViewport(0,0,tex.w,tex.h);
        active_fbo = this;
    }
    public void unbind(){
        if( active_fbo != this )
            throw new RuntimeException("Trying to unbind a non-bound FBO");
        glBindFramebuffer(GL_FRAMEBUFFER,0);
        glViewport(saved_viewport[0],
                saved_viewport[1],
                saved_viewport[2],
                saved_viewport[3]
                );
        active_fbo = null;
    }
}
