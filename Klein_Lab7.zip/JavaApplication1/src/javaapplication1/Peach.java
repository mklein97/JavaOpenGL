/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import math3d.vec3;
import static math3d.functions.translation;

/**
 *
 * @author jhudson
 */
public class Peach extends GameObject{
    Sphere sph;
    Peach(vec3 pos, vec3 vel, vec3 g){
        super(pos,vel,g,-1);
        sph = new Sphere();
    }
    void draw(){
        //set uniforms (worldMatrix)
        Program.current.setUniform("worldMatrix", translation(position));
        //Program.current.setUniform("objColor", new vec3(0.976, 0.439, 0.203));
        sph.draw();
    }
    boolean isAlive(){
        return(position.y > -4000);
    }
}