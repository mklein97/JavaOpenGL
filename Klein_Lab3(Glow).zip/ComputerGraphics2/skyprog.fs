
uniform samplerCube textures;

in vec3 v_objPosition;

out vec4 color;

void main(){
    vec4 c = texture(textures,v_objPosition);
    color = c;
}
