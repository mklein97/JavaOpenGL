#version 150

#extension GL_NV_gpu_shader5: warn

flat in int v_materialIndex;
in vec2 v_texCoord;
in vec3 v_normal;
in vec3 v_worldPos;

out vec4 color;


#define MAX_MATERIALS 16
uniform vec4 diffuseColors[MAX_MATERIALS];
uniform vec4 specularColors[MAX_MATERIALS];
uniform int textureIndices[MAX_MATERIALS];
uniform vec3 eye_pos;
uniform float shiny;

#define MAX_TEXTURES 4
uniform sampler2D diffuseTextures[MAX_TEXTURES];

struct Light {
	vec3 position;
	vec3 color;
	float positional;
	float A0, A1, A2;
};

#define NUM_LIGHTS 1
uniform Light lights[NUM_LIGHTS];

void main(){
	vec3 L, R;
    vec3 N = normalize(v_normal);
    vec3 V = normalize(eye_pos-v_worldPos);
	vec3 totald = vec3(0,0,0);
	vec3 totals = vec3(0,0,0);
	for (int i=0; i < NUM_LIGHTS; ++i){
		L = normalize(lights[i].position - lights[i].positional * v_worldPos);
		R = reflect(-L,N);
		float dp = clamp(dot(N,L),0.0,1.0);
		dp = max(dp,0.0);
		float sp = 0;
		sp = pow(max(dot(V,R),0.0), shiny);
		totald = totald + dp * lights[i].color;
		totals = totals + sp * lights[i].color;
	}
	
	
	
    color = diffuseColors[v_materialIndex];
    int ti = int(textureIndices[v_materialIndex]);
    vec4 texcolor;
    #ifdef GL_NV_gpu_shader5
        texcolor = texture( diffuseTextures[ti], v_texCoord );
    #else
        vec4 tempcolor[MAX_TEXTURES];
        tempcolor[0] = texture(diffuseTextures[0], v_texCoord);
        tempcolor[1] = texture(diffuseTextures[1], v_texCoord);
        tempcolor[2] = texture(diffuseTextures[2], v_texCoord);
        tempcolor[3] = texture(diffuseTextures[3], v_texCoord);
//        for(int i=0;i<MAX_TEXTURES;i++)
//            tempcolor[i] = texture(diffuseTextures[ti], v_texCoord);
        texcolor = tempcolor[ti];
    #endif
	
	totald = min(vec3(1), totald);
	totals = min(vec3(1), totals);
	
	vec3 dc = (diffuseColors[v_materialIndex].rgb) * totald * texcolor.xyz;
	vec3 sc = (specularColors[v_materialIndex].rgb) * totals;
	color.rgb = dc + sc;
	color.a = 1.0;
}
