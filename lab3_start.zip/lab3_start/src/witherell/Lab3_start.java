/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package witherell;

import etec2101.*;
import java.util.Iterator;
//import java.util.ArrayList;

/**
 *
 * @author jwitherell
 */
public class Lab3_start
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        ArrayList.set_increment_size(20);
        
        ArrayList<String> x = new ArrayList<String>();
        x.add("abe");
        x.add("bob");
        x.add("charles");
        x.add("doug");
        x.add("eric");
        
        ArrayList<String> y = x.subList(1, 3);
        
        // Test our iterator, walk through all values.
        Iterator i = x.iterator(ArrayList.Direction.FWD);
        while (i.hasNext())
        {
            String s = (String)i.next();
            System.out.println(s);
        }
        
        
        SortedArrayList z = new SortedArrayList();
        
        // Note: Integers implement the Comparable interface
        //Integer b = new Integer(15);
        //Integer a = new Integer(14);
        // DON'T ===> if (a < b)
        //if (a.compareTo(b) < 0)
        //{
        //    System.out.println("a is less than b");
        //}
    }
    
}
